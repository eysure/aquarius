var require = meteorInstall({"server":{"index.js":function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                    //
// server/index.js                                                                                    //
//                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                      //
var _interopRequireDefault = require("@babel/runtime/helpers/interopRequireDefault");

var _objectSpread2 = _interopRequireDefault(require("@babel/runtime/helpers/objectSpread"));

let Meteor;
module.link("meteor/meteor", {
  Meteor(v) {
    Meteor = v;
  }

}, 0);
let Accounts;
module.link("meteor/accounts-base", {
  Accounts(v) {
    Accounts = v;
  }

}, 1);

let _;

module.link("lodash", {
  default(v) {
    _ = v;
  }

}, 2);
let Methods;
module.link("./methods", {
  "*"(v) {
    Methods = v;
  }

}, 3);
let Collection;
module.link("./resources", {
  Collection(v) {
    Collection = v;
  }

}, 4);
Meteor.methods(Methods);
Accounts.onLogin(login => {
  if (login.type === "password") {
    Collection("LoginLog").insert((0, _objectSpread2.default)({}, login, {
      timesteamp: new Date()
    }));
  }
});
Accounts.onLoginFailure(login => {
  Collection("LoginErrorLog").insert((0, _objectSpread2.default)({}, login, {
    timesteamp: new Date()
  }));
});
Meteor.publish("fetchEmployeesInfo", function () {
  if (!this.userId) return null;
  return Collection("employees").find({
    status: 1
  }, {
    fields: {
      _id: 1,
      nickname: 1,
      email: 1,
      name_cn: 1,
      fn_en: 1,
      ln_en: 1,
      mobile: 1,
      ext: 1,
      avatar: 1,
      preferences: 1
    }
  });
});
Meteor.publish("myEmployeeInfo", function () {
  if (!this.userId) return null;
  return Collection("employees").find({
    email: getEmailById(this.userId)
  }, {
    fields: {
      _id: 1,
      nickname: 1,
      email: 1,
      name_cn: 1,
      fn_en: 1,
      ln_en: 1,
      mobile: 1,
      ext: 1,
      avatar: 1,
      preferences: 1,
      status: 1
    }
  });
});
Meteor.publish("allEmployeesInfo", function () {
  if (!this.userId) return null;
  return [Collection("employees").find({
    hide: {
      $exists: false
    },
    status: 1
  }, {
    fields: {
      _id: 1,
      nickname: 1,
      email: 1,
      name_cn: 1,
      fn_en: 1,
      ln_en: 1,
      mobile: 1,
      ext: 1,
      avatar: 1
    }
  }), Collection("employees_assign").find({
    time_end: {
      $exists: false
    }
  }), Collection("depts").find(), Collection("depts_groups").find(), Collection("job_title").find()];
});

getEmailById = userId => {
  let user = Meteor.users.findOne({
    _id: userId
  });
  if (!user) return null;
  return user.emails[0].address;
};
////////////////////////////////////////////////////////////////////////////////////////////////////////

},"methods.js":function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                    //
// server/methods.js                                                                                  //
//                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                      //
module.export({
  getSystemDefaultAuth: () => getSystemDefaultAuth,
  getClientOSSInfo: () => getClientOSSInfo,
  testEmployeeExist: () => testEmployeeExist,
  uploadDesktop: () => uploadDesktop,
  uploadAvatar: () => uploadAvatar
});

let _;

module.link("lodash", {
  default(v) {
    _ = v;
  }

}, 0);
let uuidv4;
module.link("uuid/v4", {
  default(v) {
    uuidv4 = v;
  }

}, 1);
let Collection, oss;
module.link("./resources", {
  Collection(v) {
    Collection = v;
  },

  oss(v) {
    oss = v;
  }

}, 2);

getEmailById = userId => {
  let user = Meteor.users.findOne({
    _id: userId
  });
  if (!user) return null;
  return user.emails[0].address;
};
/**
 * Return the system collection default auth
 */


function getSystemDefaultAuth() {
  let defaultAuth = Collection("system").findOne({
    key: "defaultAuth"
  });

  if (!defaultAuth) {
    console.error("No system collection founded! Check the connection to MongoCollection database.");
    return null;
  }

  return defaultAuth.value;
}

function getClientOSSInfo() {
  return Collection("system").findOne({
    key: "ossAuth"
  }, {
    fields: {
      _id: 0,
      region: 1,
      bucket: 1
    }
  });
}

function testEmployeeExist() {
  if (!this.userId) return null;
  return Collection("employees").findOne({
    email: getEmailById(this.userId)
  }, {
    fields: {
      _id: 1,
      nickname: 1,
      email: 1,
      name_cn: 1,
      fn_en: 1,
      ln_en: 1,
      mobile: 1,
      ext: 1,
      avatar: 1,
      preferences: 1,
      status: 1
    }
  });
}

function uploadDesktop(fileInfo, fileData) {
  if (!this.userId) return null;
  let email = getEmailById(this.userId);
  let employee = Collection("employees").findOne({
    email
  });
  if (!employee) return null;
  let prefix = "assets/user/desktop/";

  let oldDesktop = _.get(employee, "preferences.desktop");

  let relPath = uuidv4() + "." + fileInfo.name.split(".").pop();
  let client = oss();
  let path = prefix + relPath;

  function deleteFile() {
    return Promise.asyncApply(() => {
      try {
        Promise.await(client.delete(prefix + oldDesktop));
      } catch (err) {
        throw new Meteor.Error(err);
      }
    });
  }

  function put() {
    return Promise.asyncApply(() => {
      try {
        Promise.await(client.put(path, new Buffer(fileData, "binary")));
        Collection("employees").update({
          email
        }, {
          $set: {
            preferences: {
              desktop: relPath
            }
          }
        });

        if (oldDesktop) {
          deleteFile();
        }

        return relPath;
      } catch (err) {
        throw new Meteor.Error(err);
      }
    });
  }

  return put();
}

function uploadAvatar(fileInfo, fileData) {
  if (!this.userId) return null;
  let email = getEmailById(this.userId);
  let employee = Collection("employees").findOne({
    email
  });
  if (!employee) return null;
  let prefix = "assets/user/avatar/";
  let oldAvatar = employee.avatar;
  let relPath = uuidv4() + "." + fileInfo.name.split(".").pop();
  let client = oss();
  let path = prefix + relPath;

  function deleteFile() {
    return Promise.asyncApply(() => {
      try {
        Promise.await(client.delete(prefix + oldAvatar));
      } catch (err) {
        throw new Meteor.Error(err);
      }
    });
  }

  function put() {
    return Promise.asyncApply(() => {
      try {
        Promise.await(client.put(path, new Buffer(fileData, "binary")));
        Collection("employees").update({
          email
        }, {
          $set: {
            avatar: relPath
          }
        });

        if (oldAvatar) {
          deleteFile();
        }

        return relPath;
      } catch (err) {
        throw new Meteor.Error(err);
      }
    });
  }

  return put();
}
////////////////////////////////////////////////////////////////////////////////////////////////////////

},"resources.js":function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                    //
// server/resources.js                                                                                //
//                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                      //
module.export({
  Collection: () => Collection,
  oss: () => oss
});
let Mongo;
module.link("meteor/mongo", {
  Mongo(v) {
    Mongo = v;
  }

}, 0);
let OSS;
module.link("ali-oss", {
  default(v) {
    OSS = v;
  }

}, 1);
let collections = {};

function Collection(collection) {
  if (collections[collection]) return collections[collection];
  let newCollection = new Mongo.Collection(collection);

  if (!newCollection) {
    console.error("No collection named: " + collection);
    return null;
  }

  collections[collection] = newCollection;
  return newCollection;
}

/**
 * Notice: Change OSS Auth need to restart the server, due to the performance issue.
 */
const ossAuth = Collection("system").findOne({
  key: "ossAuth"
}, {
  fields: {
    _id: 0,
    region: 1,
    bucket: 1,
    accessKeyId: 1,
    accessKeySecret: 1
  }
});

if (!ossAuth) {
  throw "OSS Auth is not found in system collection! please check the MongoDB connection!";
}

function oss() {
  return new OSS(ossAuth);
}
////////////////////////////////////////////////////////////////////////////////////////////////////////

}}},{
  "extensions": [
    ".js",
    ".json"
  ]
});

var exports = require("/server/index.js");
//# sourceURL=meteor://💻app/app/app.js
//# sourceMappingURL=data:application/json;charset=utf8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIm1ldGVvcjovL/CfkrthcHAvc2VydmVyL2luZGV4LmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9zZXJ2ZXIvbWV0aG9kcy5qcyIsIm1ldGVvcjovL/CfkrthcHAvc2VydmVyL3Jlc291cmNlcy5qcyJdLCJuYW1lcyI6WyJNZXRlb3IiLCJtb2R1bGUiLCJsaW5rIiwidiIsIkFjY291bnRzIiwiXyIsImRlZmF1bHQiLCJNZXRob2RzIiwiQ29sbGVjdGlvbiIsIm1ldGhvZHMiLCJvbkxvZ2luIiwibG9naW4iLCJ0eXBlIiwiaW5zZXJ0IiwidGltZXN0ZWFtcCIsIkRhdGUiLCJvbkxvZ2luRmFpbHVyZSIsInB1Ymxpc2giLCJ1c2VySWQiLCJmaW5kIiwic3RhdHVzIiwiZmllbGRzIiwiX2lkIiwibmlja25hbWUiLCJlbWFpbCIsIm5hbWVfY24iLCJmbl9lbiIsImxuX2VuIiwibW9iaWxlIiwiZXh0IiwiYXZhdGFyIiwicHJlZmVyZW5jZXMiLCJnZXRFbWFpbEJ5SWQiLCJoaWRlIiwiJGV4aXN0cyIsInRpbWVfZW5kIiwidXNlciIsInVzZXJzIiwiZmluZE9uZSIsImVtYWlscyIsImFkZHJlc3MiLCJleHBvcnQiLCJnZXRTeXN0ZW1EZWZhdWx0QXV0aCIsImdldENsaWVudE9TU0luZm8iLCJ0ZXN0RW1wbG95ZWVFeGlzdCIsInVwbG9hZERlc2t0b3AiLCJ1cGxvYWRBdmF0YXIiLCJ1dWlkdjQiLCJvc3MiLCJkZWZhdWx0QXV0aCIsImtleSIsImNvbnNvbGUiLCJlcnJvciIsInZhbHVlIiwicmVnaW9uIiwiYnVja2V0IiwiZmlsZUluZm8iLCJmaWxlRGF0YSIsImVtcGxveWVlIiwicHJlZml4Iiwib2xkRGVza3RvcCIsImdldCIsInJlbFBhdGgiLCJuYW1lIiwic3BsaXQiLCJwb3AiLCJjbGllbnQiLCJwYXRoIiwiZGVsZXRlRmlsZSIsImRlbGV0ZSIsImVyciIsIkVycm9yIiwicHV0IiwiQnVmZmVyIiwidXBkYXRlIiwiJHNldCIsImRlc2t0b3AiLCJvbGRBdmF0YXIiLCJNb25nbyIsIk9TUyIsImNvbGxlY3Rpb25zIiwiY29sbGVjdGlvbiIsIm5ld0NvbGxlY3Rpb24iLCJvc3NBdXRoIiwiYWNjZXNzS2V5SWQiLCJhY2Nlc3NLZXlTZWNyZXQiXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7OztBQUFBLElBQUlBLE1BQUo7QUFBV0MsTUFBTSxDQUFDQyxJQUFQLENBQVksZUFBWixFQUE0QjtBQUFDRixRQUFNLENBQUNHLENBQUQsRUFBRztBQUFDSCxVQUFNLEdBQUNHLENBQVA7QUFBUzs7QUFBcEIsQ0FBNUIsRUFBa0QsQ0FBbEQ7QUFBcUQsSUFBSUMsUUFBSjtBQUFhSCxNQUFNLENBQUNDLElBQVAsQ0FBWSxzQkFBWixFQUFtQztBQUFDRSxVQUFRLENBQUNELENBQUQsRUFBRztBQUFDQyxZQUFRLEdBQUNELENBQVQ7QUFBVzs7QUFBeEIsQ0FBbkMsRUFBNkQsQ0FBN0Q7O0FBQWdFLElBQUlFLENBQUo7O0FBQU1KLE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLFFBQVosRUFBcUI7QUFBQ0ksU0FBTyxDQUFDSCxDQUFELEVBQUc7QUFBQ0UsS0FBQyxHQUFDRixDQUFGO0FBQUk7O0FBQWhCLENBQXJCLEVBQXVDLENBQXZDO0FBQTBDLElBQUlJLE9BQUo7QUFBWU4sTUFBTSxDQUFDQyxJQUFQLENBQVksV0FBWixFQUF3QjtBQUFDLE1BQUlDLENBQUosRUFBTTtBQUFDSSxXQUFPLEdBQUNKLENBQVI7QUFBVTs7QUFBbEIsQ0FBeEIsRUFBNEMsQ0FBNUM7QUFBK0MsSUFBSUssVUFBSjtBQUFlUCxNQUFNLENBQUNDLElBQVAsQ0FBWSxhQUFaLEVBQTBCO0FBQUNNLFlBQVUsQ0FBQ0wsQ0FBRCxFQUFHO0FBQUNLLGNBQVUsR0FBQ0wsQ0FBWDtBQUFhOztBQUE1QixDQUExQixFQUF3RCxDQUF4RDtBQU12UUgsTUFBTSxDQUFDUyxPQUFQLENBQWVGLE9BQWY7QUFFQUgsUUFBUSxDQUFDTSxPQUFULENBQWlCQyxLQUFLLElBQUk7QUFDdEIsTUFBSUEsS0FBSyxDQUFDQyxJQUFOLEtBQWUsVUFBbkIsRUFBK0I7QUFDM0JKLGNBQVUsQ0FBQyxVQUFELENBQVYsQ0FBdUJLLE1BQXZCLGlDQUFtQ0YsS0FBbkM7QUFBMENHLGdCQUFVLEVBQUUsSUFBSUMsSUFBSjtBQUF0RDtBQUNIO0FBQ0osQ0FKRDtBQU1BWCxRQUFRLENBQUNZLGNBQVQsQ0FBd0JMLEtBQUssSUFBSTtBQUM3QkgsWUFBVSxDQUFDLGVBQUQsQ0FBVixDQUE0QkssTUFBNUIsaUNBQXdDRixLQUF4QztBQUErQ0csY0FBVSxFQUFFLElBQUlDLElBQUo7QUFBM0Q7QUFDSCxDQUZEO0FBSUFmLE1BQU0sQ0FBQ2lCLE9BQVAsQ0FBZSxvQkFBZixFQUFxQyxZQUFXO0FBQzVDLE1BQUksQ0FBQyxLQUFLQyxNQUFWLEVBQWtCLE9BQU8sSUFBUDtBQUVsQixTQUFPVixVQUFVLENBQUMsV0FBRCxDQUFWLENBQXdCVyxJQUF4QixDQUNIO0FBQUVDLFVBQU0sRUFBRTtBQUFWLEdBREcsRUFFSDtBQUNJQyxVQUFNLEVBQUU7QUFDSkMsU0FBRyxFQUFFLENBREQ7QUFFSkMsY0FBUSxFQUFFLENBRk47QUFHSkMsV0FBSyxFQUFFLENBSEg7QUFJSkMsYUFBTyxFQUFFLENBSkw7QUFLSkMsV0FBSyxFQUFFLENBTEg7QUFNSkMsV0FBSyxFQUFFLENBTkg7QUFPSkMsWUFBTSxFQUFFLENBUEo7QUFRSkMsU0FBRyxFQUFFLENBUkQ7QUFTSkMsWUFBTSxFQUFFLENBVEo7QUFVSkMsaUJBQVcsRUFBRTtBQVZUO0FBRFosR0FGRyxDQUFQO0FBaUJILENBcEJEO0FBc0JBL0IsTUFBTSxDQUFDaUIsT0FBUCxDQUFlLGdCQUFmLEVBQWlDLFlBQVc7QUFDeEMsTUFBSSxDQUFDLEtBQUtDLE1BQVYsRUFBa0IsT0FBTyxJQUFQO0FBRWxCLFNBQU9WLFVBQVUsQ0FBQyxXQUFELENBQVYsQ0FBd0JXLElBQXhCLENBQ0g7QUFBRUssU0FBSyxFQUFFUSxZQUFZLENBQUMsS0FBS2QsTUFBTjtBQUFyQixHQURHLEVBRUg7QUFDSUcsVUFBTSxFQUFFO0FBQ0pDLFNBQUcsRUFBRSxDQUREO0FBRUpDLGNBQVEsRUFBRSxDQUZOO0FBR0pDLFdBQUssRUFBRSxDQUhIO0FBSUpDLGFBQU8sRUFBRSxDQUpMO0FBS0pDLFdBQUssRUFBRSxDQUxIO0FBTUpDLFdBQUssRUFBRSxDQU5IO0FBT0pDLFlBQU0sRUFBRSxDQVBKO0FBUUpDLFNBQUcsRUFBRSxDQVJEO0FBU0pDLFlBQU0sRUFBRSxDQVRKO0FBVUpDLGlCQUFXLEVBQUUsQ0FWVDtBQVdKWCxZQUFNLEVBQUU7QUFYSjtBQURaLEdBRkcsQ0FBUDtBQWtCSCxDQXJCRDtBQXVCQXBCLE1BQU0sQ0FBQ2lCLE9BQVAsQ0FBZSxrQkFBZixFQUFtQyxZQUFXO0FBQzFDLE1BQUksQ0FBQyxLQUFLQyxNQUFWLEVBQWtCLE9BQU8sSUFBUDtBQUVsQixTQUFPLENBQ0hWLFVBQVUsQ0FBQyxXQUFELENBQVYsQ0FBd0JXLElBQXhCLENBQ0k7QUFBRWMsUUFBSSxFQUFFO0FBQUVDLGFBQU8sRUFBRTtBQUFYLEtBQVI7QUFBNEJkLFVBQU0sRUFBRTtBQUFwQyxHQURKLEVBRUk7QUFDSUMsVUFBTSxFQUFFO0FBQ0pDLFNBQUcsRUFBRSxDQUREO0FBRUpDLGNBQVEsRUFBRSxDQUZOO0FBR0pDLFdBQUssRUFBRSxDQUhIO0FBSUpDLGFBQU8sRUFBRSxDQUpMO0FBS0pDLFdBQUssRUFBRSxDQUxIO0FBTUpDLFdBQUssRUFBRSxDQU5IO0FBT0pDLFlBQU0sRUFBRSxDQVBKO0FBUUpDLFNBQUcsRUFBRSxDQVJEO0FBU0pDLFlBQU0sRUFBRTtBQVRKO0FBRFosR0FGSixDQURHLEVBaUJIdEIsVUFBVSxDQUFDLGtCQUFELENBQVYsQ0FBK0JXLElBQS9CLENBQW9DO0FBQUVnQixZQUFRLEVBQUU7QUFBRUQsYUFBTyxFQUFFO0FBQVg7QUFBWixHQUFwQyxDQWpCRyxFQWtCSDFCLFVBQVUsQ0FBQyxPQUFELENBQVYsQ0FBb0JXLElBQXBCLEVBbEJHLEVBbUJIWCxVQUFVLENBQUMsY0FBRCxDQUFWLENBQTJCVyxJQUEzQixFQW5CRyxFQW9CSFgsVUFBVSxDQUFDLFdBQUQsQ0FBVixDQUF3QlcsSUFBeEIsRUFwQkcsQ0FBUDtBQXNCSCxDQXpCRDs7QUEyQkFhLFlBQVksR0FBR2QsTUFBTSxJQUFJO0FBQ3JCLE1BQUlrQixJQUFJLEdBQUdwQyxNQUFNLENBQUNxQyxLQUFQLENBQWFDLE9BQWIsQ0FBcUI7QUFBRWhCLE9BQUcsRUFBRUo7QUFBUCxHQUFyQixDQUFYO0FBQ0EsTUFBSSxDQUFDa0IsSUFBTCxFQUFXLE9BQU8sSUFBUDtBQUNYLFNBQU9BLElBQUksQ0FBQ0csTUFBTCxDQUFZLENBQVosRUFBZUMsT0FBdEI7QUFDSCxDQUpELEM7Ozs7Ozs7Ozs7O0FDMUZBdkMsTUFBTSxDQUFDd0MsTUFBUCxDQUFjO0FBQUNDLHNCQUFvQixFQUFDLE1BQUlBLG9CQUExQjtBQUErQ0Msa0JBQWdCLEVBQUMsTUFBSUEsZ0JBQXBFO0FBQXFGQyxtQkFBaUIsRUFBQyxNQUFJQSxpQkFBM0c7QUFBNkhDLGVBQWEsRUFBQyxNQUFJQSxhQUEvSTtBQUE2SkMsY0FBWSxFQUFDLE1BQUlBO0FBQTlLLENBQWQ7O0FBQTJNLElBQUl6QyxDQUFKOztBQUFNSixNQUFNLENBQUNDLElBQVAsQ0FBWSxRQUFaLEVBQXFCO0FBQUNJLFNBQU8sQ0FBQ0gsQ0FBRCxFQUFHO0FBQUNFLEtBQUMsR0FBQ0YsQ0FBRjtBQUFJOztBQUFoQixDQUFyQixFQUF1QyxDQUF2QztBQUEwQyxJQUFJNEMsTUFBSjtBQUFXOUMsTUFBTSxDQUFDQyxJQUFQLENBQVksU0FBWixFQUFzQjtBQUFDSSxTQUFPLENBQUNILENBQUQsRUFBRztBQUFDNEMsVUFBTSxHQUFDNUMsQ0FBUDtBQUFTOztBQUFyQixDQUF0QixFQUE2QyxDQUE3QztBQUFnRCxJQUFJSyxVQUFKLEVBQWV3QyxHQUFmO0FBQW1CL0MsTUFBTSxDQUFDQyxJQUFQLENBQVksYUFBWixFQUEwQjtBQUFDTSxZQUFVLENBQUNMLENBQUQsRUFBRztBQUFDSyxjQUFVLEdBQUNMLENBQVg7QUFBYSxHQUE1Qjs7QUFBNkI2QyxLQUFHLENBQUM3QyxDQUFELEVBQUc7QUFBQzZDLE9BQUcsR0FBQzdDLENBQUo7QUFBTTs7QUFBMUMsQ0FBMUIsRUFBc0UsQ0FBdEU7O0FBSXpVNkIsWUFBWSxHQUFHZCxNQUFNLElBQUk7QUFDckIsTUFBSWtCLElBQUksR0FBR3BDLE1BQU0sQ0FBQ3FDLEtBQVAsQ0FBYUMsT0FBYixDQUFxQjtBQUFFaEIsT0FBRyxFQUFFSjtBQUFQLEdBQXJCLENBQVg7QUFDQSxNQUFJLENBQUNrQixJQUFMLEVBQVcsT0FBTyxJQUFQO0FBQ1gsU0FBT0EsSUFBSSxDQUFDRyxNQUFMLENBQVksQ0FBWixFQUFlQyxPQUF0QjtBQUNILENBSkQ7QUFNQTs7Ozs7QUFHTyxTQUFTRSxvQkFBVCxHQUFnQztBQUNuQyxNQUFJTyxXQUFXLEdBQUd6QyxVQUFVLENBQUMsUUFBRCxDQUFWLENBQXFCOEIsT0FBckIsQ0FBNkI7QUFBRVksT0FBRyxFQUFFO0FBQVAsR0FBN0IsQ0FBbEI7O0FBQ0EsTUFBSSxDQUFDRCxXQUFMLEVBQWtCO0FBQ2RFLFdBQU8sQ0FBQ0MsS0FBUixDQUFjLGlGQUFkO0FBQ0EsV0FBTyxJQUFQO0FBQ0g7O0FBQ0QsU0FBT0gsV0FBVyxDQUFDSSxLQUFuQjtBQUNIOztBQUVNLFNBQVNWLGdCQUFULEdBQTRCO0FBQy9CLFNBQU9uQyxVQUFVLENBQUMsUUFBRCxDQUFWLENBQXFCOEIsT0FBckIsQ0FBNkI7QUFBRVksT0FBRyxFQUFFO0FBQVAsR0FBN0IsRUFBaUQ7QUFBRTdCLFVBQU0sRUFBRTtBQUFFQyxTQUFHLEVBQUUsQ0FBUDtBQUFVZ0MsWUFBTSxFQUFFLENBQWxCO0FBQXFCQyxZQUFNLEVBQUU7QUFBN0I7QUFBVixHQUFqRCxDQUFQO0FBQ0g7O0FBS00sU0FBU1gsaUJBQVQsR0FBNkI7QUFDaEMsTUFBSSxDQUFDLEtBQUsxQixNQUFWLEVBQWtCLE9BQU8sSUFBUDtBQUVsQixTQUFPVixVQUFVLENBQUMsV0FBRCxDQUFWLENBQXdCOEIsT0FBeEIsQ0FDSDtBQUFFZCxTQUFLLEVBQUVRLFlBQVksQ0FBQyxLQUFLZCxNQUFOO0FBQXJCLEdBREcsRUFFSDtBQUNJRyxVQUFNLEVBQUU7QUFDSkMsU0FBRyxFQUFFLENBREQ7QUFFSkMsY0FBUSxFQUFFLENBRk47QUFHSkMsV0FBSyxFQUFFLENBSEg7QUFJSkMsYUFBTyxFQUFFLENBSkw7QUFLSkMsV0FBSyxFQUFFLENBTEg7QUFNSkMsV0FBSyxFQUFFLENBTkg7QUFPSkMsWUFBTSxFQUFFLENBUEo7QUFRSkMsU0FBRyxFQUFFLENBUkQ7QUFTSkMsWUFBTSxFQUFFLENBVEo7QUFVSkMsaUJBQVcsRUFBRSxDQVZUO0FBV0pYLFlBQU0sRUFBRTtBQVhKO0FBRFosR0FGRyxDQUFQO0FBa0JIOztBQUVNLFNBQVN5QixhQUFULENBQXVCVyxRQUF2QixFQUFpQ0MsUUFBakMsRUFBMkM7QUFDOUMsTUFBSSxDQUFDLEtBQUt2QyxNQUFWLEVBQWtCLE9BQU8sSUFBUDtBQUVsQixNQUFJTSxLQUFLLEdBQUdRLFlBQVksQ0FBQyxLQUFLZCxNQUFOLENBQXhCO0FBQ0EsTUFBSXdDLFFBQVEsR0FBR2xELFVBQVUsQ0FBQyxXQUFELENBQVYsQ0FBd0I4QixPQUF4QixDQUFnQztBQUFFZDtBQUFGLEdBQWhDLENBQWY7QUFDQSxNQUFJLENBQUNrQyxRQUFMLEVBQWUsT0FBTyxJQUFQO0FBRWYsTUFBSUMsTUFBTSxHQUFHLHNCQUFiOztBQUVBLE1BQUlDLFVBQVUsR0FBR3ZELENBQUMsQ0FBQ3dELEdBQUYsQ0FBTUgsUUFBTixFQUFnQixxQkFBaEIsQ0FBakI7O0FBRUEsTUFBSUksT0FBTyxHQUFHZixNQUFNLEtBQUssR0FBWCxHQUFpQlMsUUFBUSxDQUFDTyxJQUFULENBQWNDLEtBQWQsQ0FBb0IsR0FBcEIsRUFBeUJDLEdBQXpCLEVBQS9CO0FBRUEsTUFBSUMsTUFBTSxHQUFHbEIsR0FBRyxFQUFoQjtBQUNBLE1BQUltQixJQUFJLEdBQUdSLE1BQU0sR0FBR0csT0FBcEI7O0FBRUEsV0FBZU0sVUFBZjtBQUFBLG9DQUE0QjtBQUN4QixVQUFJO0FBQ0Esc0JBQU1GLE1BQU0sQ0FBQ0csTUFBUCxDQUFjVixNQUFNLEdBQUdDLFVBQXZCLENBQU47QUFDSCxPQUZELENBRUUsT0FBT1UsR0FBUCxFQUFZO0FBQ1YsY0FBTSxJQUFJdEUsTUFBTSxDQUFDdUUsS0FBWCxDQUFpQkQsR0FBakIsQ0FBTjtBQUNIO0FBQ0osS0FORDtBQUFBOztBQVFBLFdBQWVFLEdBQWY7QUFBQSxvQ0FBcUI7QUFDakIsVUFBSTtBQUNBLHNCQUFNTixNQUFNLENBQUNNLEdBQVAsQ0FBV0wsSUFBWCxFQUFpQixJQUFJTSxNQUFKLENBQVdoQixRQUFYLEVBQXFCLFFBQXJCLENBQWpCLENBQU47QUFDQWpELGtCQUFVLENBQUMsV0FBRCxDQUFWLENBQXdCa0UsTUFBeEIsQ0FBK0I7QUFBRWxEO0FBQUYsU0FBL0IsRUFBMEM7QUFBRW1ELGNBQUksRUFBRTtBQUFFNUMsdUJBQVcsRUFBRTtBQUFFNkMscUJBQU8sRUFBRWQ7QUFBWDtBQUFmO0FBQVIsU0FBMUM7O0FBQ0EsWUFBSUYsVUFBSixFQUFnQjtBQUNaUSxvQkFBVTtBQUNiOztBQUNELGVBQU9OLE9BQVA7QUFDSCxPQVBELENBT0UsT0FBT1EsR0FBUCxFQUFZO0FBQ1YsY0FBTSxJQUFJdEUsTUFBTSxDQUFDdUUsS0FBWCxDQUFpQkQsR0FBakIsQ0FBTjtBQUNIO0FBQ0osS0FYRDtBQUFBOztBQWFBLFNBQU9FLEdBQUcsRUFBVjtBQUNIOztBQUVNLFNBQVMxQixZQUFULENBQXNCVSxRQUF0QixFQUFnQ0MsUUFBaEMsRUFBMEM7QUFDN0MsTUFBSSxDQUFDLEtBQUt2QyxNQUFWLEVBQWtCLE9BQU8sSUFBUDtBQUVsQixNQUFJTSxLQUFLLEdBQUdRLFlBQVksQ0FBQyxLQUFLZCxNQUFOLENBQXhCO0FBQ0EsTUFBSXdDLFFBQVEsR0FBR2xELFVBQVUsQ0FBQyxXQUFELENBQVYsQ0FBd0I4QixPQUF4QixDQUFnQztBQUFFZDtBQUFGLEdBQWhDLENBQWY7QUFDQSxNQUFJLENBQUNrQyxRQUFMLEVBQWUsT0FBTyxJQUFQO0FBRWYsTUFBSUMsTUFBTSxHQUFHLHFCQUFiO0FBRUEsTUFBSWtCLFNBQVMsR0FBR25CLFFBQVEsQ0FBQzVCLE1BQXpCO0FBRUEsTUFBSWdDLE9BQU8sR0FBR2YsTUFBTSxLQUFLLEdBQVgsR0FBaUJTLFFBQVEsQ0FBQ08sSUFBVCxDQUFjQyxLQUFkLENBQW9CLEdBQXBCLEVBQXlCQyxHQUF6QixFQUEvQjtBQUVBLE1BQUlDLE1BQU0sR0FBR2xCLEdBQUcsRUFBaEI7QUFDQSxNQUFJbUIsSUFBSSxHQUFHUixNQUFNLEdBQUdHLE9BQXBCOztBQUVBLFdBQWVNLFVBQWY7QUFBQSxvQ0FBNEI7QUFDeEIsVUFBSTtBQUNBLHNCQUFNRixNQUFNLENBQUNHLE1BQVAsQ0FBY1YsTUFBTSxHQUFHa0IsU0FBdkIsQ0FBTjtBQUNILE9BRkQsQ0FFRSxPQUFPUCxHQUFQLEVBQVk7QUFDVixjQUFNLElBQUl0RSxNQUFNLENBQUN1RSxLQUFYLENBQWlCRCxHQUFqQixDQUFOO0FBQ0g7QUFDSixLQU5EO0FBQUE7O0FBUUEsV0FBZUUsR0FBZjtBQUFBLG9DQUFxQjtBQUNqQixVQUFJO0FBQ0Esc0JBQU1OLE1BQU0sQ0FBQ00sR0FBUCxDQUFXTCxJQUFYLEVBQWlCLElBQUlNLE1BQUosQ0FBV2hCLFFBQVgsRUFBcUIsUUFBckIsQ0FBakIsQ0FBTjtBQUNBakQsa0JBQVUsQ0FBQyxXQUFELENBQVYsQ0FBd0JrRSxNQUF4QixDQUErQjtBQUFFbEQ7QUFBRixTQUEvQixFQUEwQztBQUFFbUQsY0FBSSxFQUFFO0FBQUU3QyxrQkFBTSxFQUFFZ0M7QUFBVjtBQUFSLFNBQTFDOztBQUNBLFlBQUllLFNBQUosRUFBZTtBQUNYVCxvQkFBVTtBQUNiOztBQUNELGVBQU9OLE9BQVA7QUFDSCxPQVBELENBT0UsT0FBT1EsR0FBUCxFQUFZO0FBQ1YsY0FBTSxJQUFJdEUsTUFBTSxDQUFDdUUsS0FBWCxDQUFpQkQsR0FBakIsQ0FBTjtBQUNIO0FBQ0osS0FYRDtBQUFBOztBQWFBLFNBQU9FLEdBQUcsRUFBVjtBQUNILEM7Ozs7Ozs7Ozs7O0FDbElEdkUsTUFBTSxDQUFDd0MsTUFBUCxDQUFjO0FBQUNqQyxZQUFVLEVBQUMsTUFBSUEsVUFBaEI7QUFBMkJ3QyxLQUFHLEVBQUMsTUFBSUE7QUFBbkMsQ0FBZDtBQUF1RCxJQUFJOEIsS0FBSjtBQUFVN0UsTUFBTSxDQUFDQyxJQUFQLENBQVksY0FBWixFQUEyQjtBQUFDNEUsT0FBSyxDQUFDM0UsQ0FBRCxFQUFHO0FBQUMyRSxTQUFLLEdBQUMzRSxDQUFOO0FBQVE7O0FBQWxCLENBQTNCLEVBQStDLENBQS9DO0FBQWtELElBQUk0RSxHQUFKO0FBQVE5RSxNQUFNLENBQUNDLElBQVAsQ0FBWSxTQUFaLEVBQXNCO0FBQUNJLFNBQU8sQ0FBQ0gsQ0FBRCxFQUFHO0FBQUM0RSxPQUFHLEdBQUM1RSxDQUFKO0FBQU07O0FBQWxCLENBQXRCLEVBQTBDLENBQTFDO0FBRzNILElBQUk2RSxXQUFXLEdBQUcsRUFBbEI7O0FBRU8sU0FBU3hFLFVBQVQsQ0FBb0J5RSxVQUFwQixFQUFnQztBQUNuQyxNQUFJRCxXQUFXLENBQUNDLFVBQUQsQ0FBZixFQUE2QixPQUFPRCxXQUFXLENBQUNDLFVBQUQsQ0FBbEI7QUFFN0IsTUFBSUMsYUFBYSxHQUFHLElBQUlKLEtBQUssQ0FBQ3RFLFVBQVYsQ0FBcUJ5RSxVQUFyQixDQUFwQjs7QUFDQSxNQUFJLENBQUNDLGFBQUwsRUFBb0I7QUFDaEIvQixXQUFPLENBQUNDLEtBQVIsQ0FBYywwQkFBMEI2QixVQUF4QztBQUNBLFdBQU8sSUFBUDtBQUNIOztBQUNERCxhQUFXLENBQUNDLFVBQUQsQ0FBWCxHQUEwQkMsYUFBMUI7QUFDQSxTQUFPQSxhQUFQO0FBQ0g7O0FBRUQ7OztBQUdBLE1BQU1DLE9BQU8sR0FBRzNFLFVBQVUsQ0FBQyxRQUFELENBQVYsQ0FBcUI4QixPQUFyQixDQUNaO0FBQUVZLEtBQUcsRUFBRTtBQUFQLENBRFksRUFFWjtBQUFFN0IsUUFBTSxFQUFFO0FBQUVDLE9BQUcsRUFBRSxDQUFQO0FBQVVnQyxVQUFNLEVBQUUsQ0FBbEI7QUFBcUJDLFVBQU0sRUFBRSxDQUE3QjtBQUFnQzZCLGVBQVcsRUFBRSxDQUE3QztBQUFnREMsbUJBQWUsRUFBRTtBQUFqRTtBQUFWLENBRlksQ0FBaEI7O0FBSUEsSUFBSSxDQUFDRixPQUFMLEVBQWM7QUFDVixRQUFNLGtGQUFOO0FBQ0g7O0FBRU0sU0FBU25DLEdBQVQsR0FBZTtBQUNsQixTQUFPLElBQUkrQixHQUFKLENBQVFJLE9BQVIsQ0FBUDtBQUNILEMiLCJmaWxlIjoiL2FwcC5qcyIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IE1ldGVvciB9IGZyb20gXCJtZXRlb3IvbWV0ZW9yXCI7XG5pbXBvcnQgeyBBY2NvdW50cyB9IGZyb20gXCJtZXRlb3IvYWNjb3VudHMtYmFzZVwiO1xuaW1wb3J0IF8gZnJvbSBcImxvZGFzaFwiO1xuaW1wb3J0ICogYXMgTWV0aG9kcyBmcm9tIFwiLi9tZXRob2RzXCI7XG5pbXBvcnQgeyBDb2xsZWN0aW9uIH0gZnJvbSBcIi4vcmVzb3VyY2VzXCI7XG5cbk1ldGVvci5tZXRob2RzKE1ldGhvZHMpO1xuXG5BY2NvdW50cy5vbkxvZ2luKGxvZ2luID0+IHtcbiAgICBpZiAobG9naW4udHlwZSA9PT0gXCJwYXNzd29yZFwiKSB7XG4gICAgICAgIENvbGxlY3Rpb24oXCJMb2dpbkxvZ1wiKS5pbnNlcnQoeyAuLi5sb2dpbiwgdGltZXN0ZWFtcDogbmV3IERhdGUoKSB9KTtcbiAgICB9XG59KTtcblxuQWNjb3VudHMub25Mb2dpbkZhaWx1cmUobG9naW4gPT4ge1xuICAgIENvbGxlY3Rpb24oXCJMb2dpbkVycm9yTG9nXCIpLmluc2VydCh7IC4uLmxvZ2luLCB0aW1lc3RlYW1wOiBuZXcgRGF0ZSgpIH0pO1xufSk7XG5cbk1ldGVvci5wdWJsaXNoKFwiZmV0Y2hFbXBsb3llZXNJbmZvXCIsIGZ1bmN0aW9uKCkge1xuICAgIGlmICghdGhpcy51c2VySWQpIHJldHVybiBudWxsO1xuXG4gICAgcmV0dXJuIENvbGxlY3Rpb24oXCJlbXBsb3llZXNcIikuZmluZChcbiAgICAgICAgeyBzdGF0dXM6IDEgfSxcbiAgICAgICAge1xuICAgICAgICAgICAgZmllbGRzOiB7XG4gICAgICAgICAgICAgICAgX2lkOiAxLFxuICAgICAgICAgICAgICAgIG5pY2tuYW1lOiAxLFxuICAgICAgICAgICAgICAgIGVtYWlsOiAxLFxuICAgICAgICAgICAgICAgIG5hbWVfY246IDEsXG4gICAgICAgICAgICAgICAgZm5fZW46IDEsXG4gICAgICAgICAgICAgICAgbG5fZW46IDEsXG4gICAgICAgICAgICAgICAgbW9iaWxlOiAxLFxuICAgICAgICAgICAgICAgIGV4dDogMSxcbiAgICAgICAgICAgICAgICBhdmF0YXI6IDEsXG4gICAgICAgICAgICAgICAgcHJlZmVyZW5jZXM6IDFcbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICk7XG59KTtcblxuTWV0ZW9yLnB1Ymxpc2goXCJteUVtcGxveWVlSW5mb1wiLCBmdW5jdGlvbigpIHtcbiAgICBpZiAoIXRoaXMudXNlcklkKSByZXR1cm4gbnVsbDtcblxuICAgIHJldHVybiBDb2xsZWN0aW9uKFwiZW1wbG95ZWVzXCIpLmZpbmQoXG4gICAgICAgIHsgZW1haWw6IGdldEVtYWlsQnlJZCh0aGlzLnVzZXJJZCkgfSxcbiAgICAgICAge1xuICAgICAgICAgICAgZmllbGRzOiB7XG4gICAgICAgICAgICAgICAgX2lkOiAxLFxuICAgICAgICAgICAgICAgIG5pY2tuYW1lOiAxLFxuICAgICAgICAgICAgICAgIGVtYWlsOiAxLFxuICAgICAgICAgICAgICAgIG5hbWVfY246IDEsXG4gICAgICAgICAgICAgICAgZm5fZW46IDEsXG4gICAgICAgICAgICAgICAgbG5fZW46IDEsXG4gICAgICAgICAgICAgICAgbW9iaWxlOiAxLFxuICAgICAgICAgICAgICAgIGV4dDogMSxcbiAgICAgICAgICAgICAgICBhdmF0YXI6IDEsXG4gICAgICAgICAgICAgICAgcHJlZmVyZW5jZXM6IDEsXG4gICAgICAgICAgICAgICAgc3RhdHVzOiAxXG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICApO1xufSk7XG5cbk1ldGVvci5wdWJsaXNoKFwiYWxsRW1wbG95ZWVzSW5mb1wiLCBmdW5jdGlvbigpIHtcbiAgICBpZiAoIXRoaXMudXNlcklkKSByZXR1cm4gbnVsbDtcblxuICAgIHJldHVybiBbXG4gICAgICAgIENvbGxlY3Rpb24oXCJlbXBsb3llZXNcIikuZmluZChcbiAgICAgICAgICAgIHsgaGlkZTogeyAkZXhpc3RzOiBmYWxzZSB9LCBzdGF0dXM6IDEgfSxcbiAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgICBmaWVsZHM6IHtcbiAgICAgICAgICAgICAgICAgICAgX2lkOiAxLFxuICAgICAgICAgICAgICAgICAgICBuaWNrbmFtZTogMSxcbiAgICAgICAgICAgICAgICAgICAgZW1haWw6IDEsXG4gICAgICAgICAgICAgICAgICAgIG5hbWVfY246IDEsXG4gICAgICAgICAgICAgICAgICAgIGZuX2VuOiAxLFxuICAgICAgICAgICAgICAgICAgICBsbl9lbjogMSxcbiAgICAgICAgICAgICAgICAgICAgbW9iaWxlOiAxLFxuICAgICAgICAgICAgICAgICAgICBleHQ6IDEsXG4gICAgICAgICAgICAgICAgICAgIGF2YXRhcjogMVxuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH1cbiAgICAgICAgKSxcbiAgICAgICAgQ29sbGVjdGlvbihcImVtcGxveWVlc19hc3NpZ25cIikuZmluZCh7IHRpbWVfZW5kOiB7ICRleGlzdHM6IGZhbHNlIH0gfSksXG4gICAgICAgIENvbGxlY3Rpb24oXCJkZXB0c1wiKS5maW5kKCksXG4gICAgICAgIENvbGxlY3Rpb24oXCJkZXB0c19ncm91cHNcIikuZmluZCgpLFxuICAgICAgICBDb2xsZWN0aW9uKFwiam9iX3RpdGxlXCIpLmZpbmQoKVxuICAgIF07XG59KTtcblxuZ2V0RW1haWxCeUlkID0gdXNlcklkID0+IHtcbiAgICBsZXQgdXNlciA9IE1ldGVvci51c2Vycy5maW5kT25lKHsgX2lkOiB1c2VySWQgfSk7XG4gICAgaWYgKCF1c2VyKSByZXR1cm4gbnVsbDtcbiAgICByZXR1cm4gdXNlci5lbWFpbHNbMF0uYWRkcmVzcztcbn07XG4iLCJpbXBvcnQgXyBmcm9tIFwibG9kYXNoXCI7XG5pbXBvcnQgdXVpZHY0IGZyb20gXCJ1dWlkL3Y0XCI7XG5pbXBvcnQgeyBDb2xsZWN0aW9uLCBvc3MgfSBmcm9tIFwiLi9yZXNvdXJjZXNcIjtcblxuZ2V0RW1haWxCeUlkID0gdXNlcklkID0+IHtcbiAgICBsZXQgdXNlciA9IE1ldGVvci51c2Vycy5maW5kT25lKHsgX2lkOiB1c2VySWQgfSk7XG4gICAgaWYgKCF1c2VyKSByZXR1cm4gbnVsbDtcbiAgICByZXR1cm4gdXNlci5lbWFpbHNbMF0uYWRkcmVzcztcbn07XG5cbi8qKlxuICogUmV0dXJuIHRoZSBzeXN0ZW0gY29sbGVjdGlvbiBkZWZhdWx0IGF1dGhcbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIGdldFN5c3RlbURlZmF1bHRBdXRoKCkge1xuICAgIGxldCBkZWZhdWx0QXV0aCA9IENvbGxlY3Rpb24oXCJzeXN0ZW1cIikuZmluZE9uZSh7IGtleTogXCJkZWZhdWx0QXV0aFwiIH0pO1xuICAgIGlmICghZGVmYXVsdEF1dGgpIHtcbiAgICAgICAgY29uc29sZS5lcnJvcihcIk5vIHN5c3RlbSBjb2xsZWN0aW9uIGZvdW5kZWQhIENoZWNrIHRoZSBjb25uZWN0aW9uIHRvIE1vbmdvQ29sbGVjdGlvbiBkYXRhYmFzZS5cIik7XG4gICAgICAgIHJldHVybiBudWxsO1xuICAgIH1cbiAgICByZXR1cm4gZGVmYXVsdEF1dGgudmFsdWU7XG59XG5cbmV4cG9ydCBmdW5jdGlvbiBnZXRDbGllbnRPU1NJbmZvKCkge1xuICAgIHJldHVybiBDb2xsZWN0aW9uKFwic3lzdGVtXCIpLmZpbmRPbmUoeyBrZXk6IFwib3NzQXV0aFwiIH0sIHsgZmllbGRzOiB7IF9pZDogMCwgcmVnaW9uOiAxLCBidWNrZXQ6IDEgfSB9KTtcbn1cblxuLyoqXG4gKiBSZXR1cm4gdGhlIGN1cnJlbnQgdXNlcidzIGVtcGxveWVlIGluZm8uXG4gKi9cbmV4cG9ydCBmdW5jdGlvbiB0ZXN0RW1wbG95ZWVFeGlzdCgpIHtcbiAgICBpZiAoIXRoaXMudXNlcklkKSByZXR1cm4gbnVsbDtcblxuICAgIHJldHVybiBDb2xsZWN0aW9uKFwiZW1wbG95ZWVzXCIpLmZpbmRPbmUoXG4gICAgICAgIHsgZW1haWw6IGdldEVtYWlsQnlJZCh0aGlzLnVzZXJJZCkgfSxcbiAgICAgICAge1xuICAgICAgICAgICAgZmllbGRzOiB7XG4gICAgICAgICAgICAgICAgX2lkOiAxLFxuICAgICAgICAgICAgICAgIG5pY2tuYW1lOiAxLFxuICAgICAgICAgICAgICAgIGVtYWlsOiAxLFxuICAgICAgICAgICAgICAgIG5hbWVfY246IDEsXG4gICAgICAgICAgICAgICAgZm5fZW46IDEsXG4gICAgICAgICAgICAgICAgbG5fZW46IDEsXG4gICAgICAgICAgICAgICAgbW9iaWxlOiAxLFxuICAgICAgICAgICAgICAgIGV4dDogMSxcbiAgICAgICAgICAgICAgICBhdmF0YXI6IDEsXG4gICAgICAgICAgICAgICAgcHJlZmVyZW5jZXM6IDEsXG4gICAgICAgICAgICAgICAgc3RhdHVzOiAxXG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICApO1xufVxuXG5leHBvcnQgZnVuY3Rpb24gdXBsb2FkRGVza3RvcChmaWxlSW5mbywgZmlsZURhdGEpIHtcbiAgICBpZiAoIXRoaXMudXNlcklkKSByZXR1cm4gbnVsbDtcblxuICAgIGxldCBlbWFpbCA9IGdldEVtYWlsQnlJZCh0aGlzLnVzZXJJZCk7XG4gICAgbGV0IGVtcGxveWVlID0gQ29sbGVjdGlvbihcImVtcGxveWVlc1wiKS5maW5kT25lKHsgZW1haWwgfSk7XG4gICAgaWYgKCFlbXBsb3llZSkgcmV0dXJuIG51bGw7XG5cbiAgICBsZXQgcHJlZml4ID0gXCJhc3NldHMvdXNlci9kZXNrdG9wL1wiO1xuXG4gICAgbGV0IG9sZERlc2t0b3AgPSBfLmdldChlbXBsb3llZSwgXCJwcmVmZXJlbmNlcy5kZXNrdG9wXCIpO1xuXG4gICAgbGV0IHJlbFBhdGggPSB1dWlkdjQoKSArIFwiLlwiICsgZmlsZUluZm8ubmFtZS5zcGxpdChcIi5cIikucG9wKCk7XG5cbiAgICBsZXQgY2xpZW50ID0gb3NzKCk7XG4gICAgbGV0IHBhdGggPSBwcmVmaXggKyByZWxQYXRoO1xuXG4gICAgYXN5bmMgZnVuY3Rpb24gZGVsZXRlRmlsZSgpIHtcbiAgICAgICAgdHJ5IHtcbiAgICAgICAgICAgIGF3YWl0IGNsaWVudC5kZWxldGUocHJlZml4ICsgb2xkRGVza3RvcCk7XG4gICAgICAgIH0gY2F0Y2ggKGVycikge1xuICAgICAgICAgICAgdGhyb3cgbmV3IE1ldGVvci5FcnJvcihlcnIpO1xuICAgICAgICB9XG4gICAgfVxuXG4gICAgYXN5bmMgZnVuY3Rpb24gcHV0KCkge1xuICAgICAgICB0cnkge1xuICAgICAgICAgICAgYXdhaXQgY2xpZW50LnB1dChwYXRoLCBuZXcgQnVmZmVyKGZpbGVEYXRhLCBcImJpbmFyeVwiKSk7XG4gICAgICAgICAgICBDb2xsZWN0aW9uKFwiZW1wbG95ZWVzXCIpLnVwZGF0ZSh7IGVtYWlsIH0sIHsgJHNldDogeyBwcmVmZXJlbmNlczogeyBkZXNrdG9wOiByZWxQYXRoIH0gfSB9KTtcbiAgICAgICAgICAgIGlmIChvbGREZXNrdG9wKSB7XG4gICAgICAgICAgICAgICAgZGVsZXRlRmlsZSgpO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgcmV0dXJuIHJlbFBhdGg7XG4gICAgICAgIH0gY2F0Y2ggKGVycikge1xuICAgICAgICAgICAgdGhyb3cgbmV3IE1ldGVvci5FcnJvcihlcnIpO1xuICAgICAgICB9XG4gICAgfVxuXG4gICAgcmV0dXJuIHB1dCgpO1xufVxuXG5leHBvcnQgZnVuY3Rpb24gdXBsb2FkQXZhdGFyKGZpbGVJbmZvLCBmaWxlRGF0YSkge1xuICAgIGlmICghdGhpcy51c2VySWQpIHJldHVybiBudWxsO1xuXG4gICAgbGV0IGVtYWlsID0gZ2V0RW1haWxCeUlkKHRoaXMudXNlcklkKTtcbiAgICBsZXQgZW1wbG95ZWUgPSBDb2xsZWN0aW9uKFwiZW1wbG95ZWVzXCIpLmZpbmRPbmUoeyBlbWFpbCB9KTtcbiAgICBpZiAoIWVtcGxveWVlKSByZXR1cm4gbnVsbDtcblxuICAgIGxldCBwcmVmaXggPSBcImFzc2V0cy91c2VyL2F2YXRhci9cIjtcblxuICAgIGxldCBvbGRBdmF0YXIgPSBlbXBsb3llZS5hdmF0YXI7XG5cbiAgICBsZXQgcmVsUGF0aCA9IHV1aWR2NCgpICsgXCIuXCIgKyBmaWxlSW5mby5uYW1lLnNwbGl0KFwiLlwiKS5wb3AoKTtcblxuICAgIGxldCBjbGllbnQgPSBvc3MoKTtcbiAgICBsZXQgcGF0aCA9IHByZWZpeCArIHJlbFBhdGg7XG5cbiAgICBhc3luYyBmdW5jdGlvbiBkZWxldGVGaWxlKCkge1xuICAgICAgICB0cnkge1xuICAgICAgICAgICAgYXdhaXQgY2xpZW50LmRlbGV0ZShwcmVmaXggKyBvbGRBdmF0YXIpO1xuICAgICAgICB9IGNhdGNoIChlcnIpIHtcbiAgICAgICAgICAgIHRocm93IG5ldyBNZXRlb3IuRXJyb3IoZXJyKTtcbiAgICAgICAgfVxuICAgIH1cblxuICAgIGFzeW5jIGZ1bmN0aW9uIHB1dCgpIHtcbiAgICAgICAgdHJ5IHtcbiAgICAgICAgICAgIGF3YWl0IGNsaWVudC5wdXQocGF0aCwgbmV3IEJ1ZmZlcihmaWxlRGF0YSwgXCJiaW5hcnlcIikpO1xuICAgICAgICAgICAgQ29sbGVjdGlvbihcImVtcGxveWVlc1wiKS51cGRhdGUoeyBlbWFpbCB9LCB7ICRzZXQ6IHsgYXZhdGFyOiByZWxQYXRoIH0gfSk7XG4gICAgICAgICAgICBpZiAob2xkQXZhdGFyKSB7XG4gICAgICAgICAgICAgICAgZGVsZXRlRmlsZSgpO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgcmV0dXJuIHJlbFBhdGg7XG4gICAgICAgIH0gY2F0Y2ggKGVycikge1xuICAgICAgICAgICAgdGhyb3cgbmV3IE1ldGVvci5FcnJvcihlcnIpO1xuICAgICAgICB9XG4gICAgfVxuXG4gICAgcmV0dXJuIHB1dCgpO1xufVxuIiwiaW1wb3J0IHsgTW9uZ28gfSBmcm9tIFwibWV0ZW9yL21vbmdvXCI7XG5pbXBvcnQgT1NTIGZyb20gXCJhbGktb3NzXCI7XG5cbmxldCBjb2xsZWN0aW9ucyA9IHt9O1xuXG5leHBvcnQgZnVuY3Rpb24gQ29sbGVjdGlvbihjb2xsZWN0aW9uKSB7XG4gICAgaWYgKGNvbGxlY3Rpb25zW2NvbGxlY3Rpb25dKSByZXR1cm4gY29sbGVjdGlvbnNbY29sbGVjdGlvbl07XG5cbiAgICBsZXQgbmV3Q29sbGVjdGlvbiA9IG5ldyBNb25nby5Db2xsZWN0aW9uKGNvbGxlY3Rpb24pO1xuICAgIGlmICghbmV3Q29sbGVjdGlvbikge1xuICAgICAgICBjb25zb2xlLmVycm9yKFwiTm8gY29sbGVjdGlvbiBuYW1lZDogXCIgKyBjb2xsZWN0aW9uKTtcbiAgICAgICAgcmV0dXJuIG51bGw7XG4gICAgfVxuICAgIGNvbGxlY3Rpb25zW2NvbGxlY3Rpb25dID0gbmV3Q29sbGVjdGlvbjtcbiAgICByZXR1cm4gbmV3Q29sbGVjdGlvbjtcbn1cblxuLyoqXG4gKiBOb3RpY2U6IENoYW5nZSBPU1MgQXV0aCBuZWVkIHRvIHJlc3RhcnQgdGhlIHNlcnZlciwgZHVlIHRvIHRoZSBwZXJmb3JtYW5jZSBpc3N1ZS5cbiAqL1xuY29uc3Qgb3NzQXV0aCA9IENvbGxlY3Rpb24oXCJzeXN0ZW1cIikuZmluZE9uZShcbiAgICB7IGtleTogXCJvc3NBdXRoXCIgfSxcbiAgICB7IGZpZWxkczogeyBfaWQ6IDAsIHJlZ2lvbjogMSwgYnVja2V0OiAxLCBhY2Nlc3NLZXlJZDogMSwgYWNjZXNzS2V5U2VjcmV0OiAxIH0gfVxuKTtcbmlmICghb3NzQXV0aCkge1xuICAgIHRocm93IFwiT1NTIEF1dGggaXMgbm90IGZvdW5kIGluIHN5c3RlbSBjb2xsZWN0aW9uISBwbGVhc2UgY2hlY2sgdGhlIE1vbmdvREIgY29ubmVjdGlvbiFcIjtcbn1cblxuZXhwb3J0IGZ1bmN0aW9uIG9zcygpIHtcbiAgICByZXR1cm4gbmV3IE9TUyhvc3NBdXRoKTtcbn1cbiJdfQ==
